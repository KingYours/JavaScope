package com.lin.jin.you.springbootflowable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFlowableApplicationTests {

    @Test
    void contextLoads() {
    }

}
