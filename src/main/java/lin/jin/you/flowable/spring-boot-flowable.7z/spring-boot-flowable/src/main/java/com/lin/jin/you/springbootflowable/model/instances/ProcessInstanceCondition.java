package com.lin.jin.you.springbootflowable.model.instances;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/26    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("流程实例条件输入对象")
public class ProcessInstanceCondition {

    @ApiModelProperty("流程实例id")
    private String processInstanceId;

    @ApiModelProperty("流程定义id")
    private String processDefinitionId;

    @ApiModelProperty("流程定义名称")
    private String processDefinitionName;

//    @ApiModelProperty("流程定义分类")
//    private String processDefinitionCategory;

    @ApiModelProperty("流程定义key")
    private String processDefinitionKey;

    @ApiModelProperty("流程实例业务key")
    private String processInstanceBusinessKey;

    @ApiModelProperty("流程是否暂停,1-激活，2-暂停")
    private int suspend;

}
