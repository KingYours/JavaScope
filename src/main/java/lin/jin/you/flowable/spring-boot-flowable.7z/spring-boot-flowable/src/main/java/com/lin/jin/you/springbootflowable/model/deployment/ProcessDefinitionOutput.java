package com.lin.jin.you.springbootflowable.model.deployment;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/24    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
public class ProcessDefinitionOutput {

    @ApiModelProperty("流程定义id")
    private String id;

    @ApiModelProperty("流程分类")
    private String category;

    @ApiModelProperty("流程名称")
    private String name;

    @ApiModelProperty("流程定义的所有版本的唯一名称")
    private String key;

    @ApiModelProperty("流程描述")
    private String description;

    @ApiModelProperty("流程版本")
    private int version;

    @ApiModelProperty("部署id")
    private String deploymentId;

    @ApiModelProperty("流程定义xml资源名称")
    private String resourceName;

    @ApiModelProperty("流程定义图片资源名称")
    private String diagramResourceName;

    @ApiModelProperty("是否存在开始节点formKey：0-否 ,1-是")
    private int startFormKey;

    @ApiModelProperty("是否定义图形符号:0-否，1-是")
    private int graphicalNotation;

    @ApiModelProperty("流程定义状态：1-激活，2-暂停")
    private int suspend;

    @ApiModelProperty("租户id")
    private String tenantId;

    @ApiModelProperty("流程定义值派生")
    private String derivedFrom;

    @ApiModelProperty("流程定义值派生的根")
    private String derivedFromRoot;

    @ApiModelProperty("流程定义的派生版本")
    private int derivedVersion;

    @ApiModelProperty("引擎版本")
    private String engineVersion;

}
