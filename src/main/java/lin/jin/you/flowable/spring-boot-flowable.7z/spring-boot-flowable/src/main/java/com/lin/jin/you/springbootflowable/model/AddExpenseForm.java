package com.lin.jin.you.springbootflowable.model;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/3/25    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
public class AddExpenseForm {

    private String userId;

    private int money;

    private String processInstanceKey;

    private String description;
}
