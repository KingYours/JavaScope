package com.lin.jin.you.springbootflowable.model.deployment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/24    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("流程定义查询条件")
public class ProcessDefinitionCondition {

    @ApiModelProperty("流程定义id")
    private String processDefinitionId;

    @ApiModelProperty("部署id")
    private String deploymentId;

    @ApiModelProperty("流程分类")
    private String category;

    @ApiModelProperty("流程名称")
    private String name;

    @ApiModelProperty("流程定义的所有版本的唯一名称")
    private String key;

    @ApiModelProperty("流程版本")
    private int version;

    @ApiModelProperty("流程定义状态：1-激活，2-暂停")
    private int suspend;

    @ApiModelProperty("租户id")
    private String tenantId;
}
