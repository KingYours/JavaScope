package com.lin.jin.you.springbootflowable.model.instances;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Map;

/**
 * 功能：通过processDefinitionId或者processDefinitionKey或者messageName启动一个实例，三者择一。
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/26    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("启动流程实例输入对象")
public class StartProcessInstanceInput {

    @ApiModelProperty("通过流程定义ID启动实例")
    private String processDefinitionId;

    // 如果流程定义有多个版本,将会使用最新的版本创建流程实例。
    @ApiModelProperty("通过流程定义Key启动实例")
    private String processDefinitionKey;

    // 消息启动事件
    @ApiModelProperty("通过消息名称启动实例")
    private String messageName;

    //使用businessKey(要求具有明确的业务含义，并且具有唯一性)与流程实例相关联,从而达到通过businessKey查询流程实例
    @ApiModelProperty(value = "流程实例业务key")
    private String businessKey;

    private Map<String,Object> variables;

    private String tenantId;

}
