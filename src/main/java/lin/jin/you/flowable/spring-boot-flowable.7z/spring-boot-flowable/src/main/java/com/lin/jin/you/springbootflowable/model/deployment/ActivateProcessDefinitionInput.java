package com.lin.jin.you.springbootflowable.model.deployment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/24    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("激活流程定义输入对象")
public class ActivateProcessDefinitionInput {

    @ApiModelProperty("流程定义ID")
    @NotBlank(message = "流程定义id不能为空")
    private String processDefinitionId;

    @ApiModelProperty("是否激活流程实例，默认为false")
    private boolean activateProcessInstances;

    @ApiModelProperty(value = "激活日期;默认为Null,立刻激活")
    private Date activateDate;
}
