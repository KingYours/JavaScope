package com.lin.jin.you.springbootflowable.model.instances;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.Map;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/26    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("流程实例输出对象")
public class ProcessInstanceOutput {

    @ApiModelProperty("流程实例id")
    private String processInstanceId;

    @ApiModelProperty("流程定义id")
    private String processDefinitionId;

    @ApiModelProperty("流程定义名称")
    private String processDefinitionName;

    @ApiModelProperty("流程定义key")
    private String processDefinitionKey;

    @ApiModelProperty("流程定义版本")
    private Integer processDefinitionVersion;

    @ApiModelProperty("部署id")
    private String deploymentId;

    @ApiModelProperty("业务key")
    private String businessKey;

    @ApiModelProperty("流程业务状态")
    private String businessStatus;

    @ApiModelProperty("流程是否暂停,1-激活，2-暂停")
    private int suspend;

    @ApiModelProperty("流程变量")
    private Map<String, Object> processVariables;

    @ApiModelProperty("租户id")
    private String tenantId;

    @ApiModelProperty("流程名称")
    private String name;

    @ApiModelProperty("流程描述")
    private String description;

    @ApiModelProperty("流程启动时间")
    private Date startTime;

    @ApiModelProperty("流程实例的用户id")
    private String startUserId;

    @ApiModelProperty("回调id")
    private String callbackId;

    @ApiModelProperty("回调类型")
    private String callbackType;

}
