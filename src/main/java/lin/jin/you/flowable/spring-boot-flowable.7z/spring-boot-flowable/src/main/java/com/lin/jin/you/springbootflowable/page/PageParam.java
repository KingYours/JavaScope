package com.lin.jin.you.springbootflowable.page;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PageParam {

    /**
     * 页号
     */
    @ApiModelProperty(value = "页号")
    private Integer pageNum = 1;
    /**
     * 页数
     */
    @ApiModelProperty(value = "页数")
    private Integer pageSize = 10;

}