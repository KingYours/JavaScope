package com.lin.jin.you.springbootflowable.controller;

import com.google.gson.Gson;
import com.lin.jin.you.springbootflowable.model.AddExpenseForm;
import lombok.extern.slf4j.Slf4j;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.repository.Deployment;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;

/**
 * 功能：我的报销流程
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/3/25    Linjy     初版
 * ──────────────────────────────────────────
 */
@Slf4j
@RestController
@RequestMapping("/expense")
public class MyExpenseController {

    @Resource
    private ProcessEngine processEngine;

    @Resource
    private RepositoryService repositoryService;

    @Resource
    private RuntimeService runtimeService;

    @Resource
    private TaskService taskService;

    @Resource
    private Gson gson;


    @PostMapping("/deployment")
    public String deployment() {
        // 多次部署
        Deployment deployment = repositoryService.createDeployment().addClasspathResource("processes/MyExpense.bpmn20.xml").deploy();
        return "部署id：" + deployment.getId();
    }


    /**
     * 添加报销
     *
     * @param addExpenseForm
     * @return
     */
    @PostMapping("/add")
    public String addExpense(@RequestBody AddExpenseForm addExpenseForm) {
        HashMap<String, Object> map = new HashMap<>(3);
        map.put("taskUser", addExpenseForm.getUserId());
        map.put("money", addExpenseForm.getMoney());
        map.put("description", addExpenseForm.getDescription());
        // 部署bpmn => 如何自动部署bpmn = >新建processes目录,将bpmn.xml文件放到该目录底下
        // 多次重启后,bpmn是否会多次部署? => 不会,只会部署一次
//        Deployment deployment = repositoryService.createDeployment().addClasspathResource("processes/MyExpense.bpmn20.xml").deploy();
//        log.info("部署bpmn,{}", deployment);
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(addExpenseForm.getProcessInstanceKey(), map);
//        log.info("流程实例对象,{}", gson.toJson(processInstance));
        return "提交报销流程成功,id:" + processInstance.getId();
    }

    /**
     * 获取该用户的任务列表
     *
     * @param userId
     * @return
     */
    @GetMapping("/list")
    public String list(String userId) {
        List<Task> tasks = taskService.createTaskQuery().taskAssignee(userId).orderByTaskCreateTime().desc().list();
        return gson.toJson(tasks);
    }

    @PostMapping("/agree")
    public String agree(String taskId) {
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        if (task == null) {
            throw new RuntimeException("流程任务不存在");
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("outcome", "通过");
        taskService.complete(taskId, map);
        return "agree";
    }

    @PostMapping("/reject")
    public String reject(String taskId) {
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        if (task == null) {
            throw new RuntimeException("流程任务不存在");
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("outcome", "驳回");
        taskService.complete(taskId, map);
        return "reject";
    }
}
