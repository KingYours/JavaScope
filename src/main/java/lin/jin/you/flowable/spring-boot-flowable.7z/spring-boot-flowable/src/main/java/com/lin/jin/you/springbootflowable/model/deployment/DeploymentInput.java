package com.lin.jin.you.springbootflowable.model.deployment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/22    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("部署输入信息")
public class DeploymentInput {

    @ApiModelProperty("部署名称")
    private String name="";

    @ApiModelProperty("部署分类")
    private String category="";

    @ApiModelProperty("部署key")
    private String key="";

    @ApiModelProperty("租户id")
    private String tenantId="";

}
