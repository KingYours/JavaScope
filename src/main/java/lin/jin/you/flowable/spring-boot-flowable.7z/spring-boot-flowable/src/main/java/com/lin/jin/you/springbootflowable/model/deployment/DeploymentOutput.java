package com.lin.jin.you.springbootflowable.model.deployment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/22    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@AllArgsConstructor
@ApiModel("部署输出信息")
public class DeploymentOutput {

    @ApiModelProperty("部署id")
    private String deploymentId;
}
