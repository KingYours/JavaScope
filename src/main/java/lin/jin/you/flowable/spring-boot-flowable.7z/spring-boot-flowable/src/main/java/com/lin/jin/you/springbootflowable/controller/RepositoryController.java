package com.lin.jin.you.springbootflowable.controller;

import com.lin.jin.you.springbootflowable.model.deployment.*;
import com.lin.jin.you.springbootflowable.model.model.ModelCondition;
import com.lin.jin.you.springbootflowable.model.model.ModelInput;
import com.lin.jin.you.springbootflowable.page.PageParam;
import com.lin.jin.you.springbootflowable.page.PageResult;
import com.lin.jin.you.springbootflowable.util.DownloadUtil;
import com.sun.istack.internal.NotNull;
import com.sunnada.gaia.commons.response.Result;
import com.sunnada.gaia.commons.response.ResultFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Update;
import org.flowable.common.engine.api.FlowableException;
import org.flowable.common.engine.api.FlowableObjectNotFoundException;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.impl.persistence.entity.ModelEntityImpl;
import org.flowable.engine.repository.*;
import org.flowable.identitylink.api.IdentityLink;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.ZipInputStream;

/**
 * 功能：bpmn.xml部署和流程定义持久化api
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/22    Linjy     初版
 * ──────────────────────────────────────────
 */
@Api(tags = "部署和流程定义API")
@RestController
@RequestMapping("/bpmn/repository")
public class RepositoryController {

    @Resource
    private RepositoryService repositoryService;

    //=============================================部署相关api=====================================================================
    @ApiOperation(value = "部署bpmn.xml文件", httpMethod = "POST")
    @PostMapping("/deployment")
    public Result<DeploymentOutput> deployment(MultipartFile file, DeploymentInput deploymentInput) throws IOException {
        Deployment deployment = repositoryService.createDeployment().addInputStream(file.getOriginalFilename(), file.getInputStream())
                // 启用重复部署过滤 => bpmn.xml文件内容一样不会在重新部署，而是返回数据库中已有的部署id
//                .enableDuplicateFiltering()
                // 部署名称
                .name(deploymentInput.getName())
                // 部署分类
                .category(deploymentInput.getCategory())
                // 部署Key
                .key(deploymentInput.getKey())
                // 租户id
                .tenantId(deploymentInput.getTenantId())
                .deploy();
        return ResultFactory.success(new DeploymentOutput(deployment.getId()));
    }

    @ApiOperation(value = "部署bpmn.xml文件zip包", httpMethod = "POST")
    @PostMapping("/deploymentZip")
    public Result<DeploymentOutput> deploymentZip(MultipartFile file, DeploymentInput deploymentInput) throws IOException {
        ZipInputStream zipInputStream = new ZipInputStream(file.getInputStream());
        Deployment deployment = repositoryService.createDeployment().addZipInputStream(zipInputStream)
                // 启用重复部署过滤 => bpmn.xml文件内容一样不会在重新部署(不管文件名是否一样)，而是返回数据库中已有的部署id
                .enableDuplicateFiltering()
                // 部署名称
                .name(deploymentInput.getName())
                // 部署分类
                .category(deploymentInput.getCategory())
                // 部署Key
                .key(deploymentInput.getKey())
                // 租户id
                .tenantId(deploymentInput.getTenantId())
                .deploy();
        return ResultFactory.success(new DeploymentOutput(deployment.getId()));
    }

    @ApiOperation(value = "删除部署,包含部署信息、流程定义、字节信息", httpMethod = "DELETE")
    @DeleteMapping("/{deploymentId}")
    public Result<String> deleteDeployment(@PathVariable String deploymentId) {
        //  正在运行中的流程是否会受影响? => 如果存在正在运行的流程实例、历史流程实例、job会抛出RuntimeException
        try {
            repositoryService.deleteDeployment(deploymentId);
        } catch (FlowableObjectNotFoundException e1) {
            return ResultFactory.failed("deploymentId为：" + deploymentId + "的部署信息不存在", null);
        } catch (RuntimeException e2) {
            return ResultFactory.failed("deploymentId为：" + deploymentId + "的部署，存在正在运行的流程实例、历史流程实例、工作信息之一,不允许删除", null);
        }
        return ResultFactory.success(deploymentId);
    }

    @ApiOperation(value = "获取部署资源名称列表", httpMethod = "GET")
    @GetMapping("/deploymentResourceNames/{deploymentId}")
    public Result<List<String>> getDeploymentResourceNames(@PathVariable String deploymentId) {
        List<String> resourceNames = repositoryService.getDeploymentResourceNames(deploymentId);
        return ResultFactory.success(resourceNames);
    }

    @ApiOperation(value = "下载部署资源", httpMethod = "GET")
    @GetMapping("/resourceAsStream/{deploymentId}")
    public void getDeploymentResourceNames(@PathVariable String deploymentId, @NotNull String resourceName, HttpServletResponse response) throws IOException {
        InputStream inputStream = repositoryService.getResourceAsStream(deploymentId, resourceName);
        // inline:默认值,表示它可以显示在网页内; attachment表示可下载 ; fileName是下载文件名字
        response.setHeader("Content-Disposition", "attachment;fileName=" + URLEncoder.encode(resourceName, "UTF-8"));
        DownloadUtil.fastCopyStream(inputStream, response.getOutputStream());
    }
    //=============================================部署相关api=====================================================================

    //==============================================流程定义相关api=================================================================

    @ApiOperation(value = "流程定义列表查询", httpMethod = "GET")
    @GetMapping("/process-definitions")
    public Result<PageResult<ProcessDefinitionOutput>> getProcessDefinitions(PageParam pageParam, ProcessDefinitionCondition condition) {
        ProcessDefinitionQuery processDefinitionQuery = repositoryService.createProcessDefinitionQuery();
        listProcessDefinitionByCondition(condition, processDefinitionQuery);
        List<ProcessDefinition> processDefinitions = processDefinitionQuery.listPage((pageParam.getPageNum() - 1) * pageParam.getPageSize(), pageParam.getPageNum() * pageParam.getPageSize());
        List<ProcessDefinitionOutput> list = processDefinitions.stream().map(this::buildProcessDefinitionOutput).collect(Collectors.toList());
        PageResult<ProcessDefinitionOutput> pageResult = new PageResult(pageParam.getPageSize(), pageParam.getPageNum(), processDefinitionQuery.count(), list);
        return ResultFactory.success(pageResult);
    }

    @ApiOperation(value = "获取流程定义", httpMethod = "GET")
    @GetMapping("/process-definitions/{processDefinitionId}")
    public Result<ProcessDefinitionOutput> getProcessDefinition(@PathVariable String processDefinitionId) {
        ProcessDefinition processDefinition = repositoryService.getProcessDefinition(processDefinitionId);
        return ResultFactory.success(buildProcessDefinitionOutput(processDefinition));
    }

    private ProcessDefinitionOutput buildProcessDefinitionOutput(ProcessDefinition processDefinition) {
        ProcessDefinitionOutput processDefinitionOutput = new ProcessDefinitionOutput();
        processDefinitionOutput.setId(processDefinition.getId());
        processDefinitionOutput.setCategory(processDefinition.getCategory());
        processDefinitionOutput.setName(processDefinition.getName());
        processDefinitionOutput.setKey(processDefinition.getKey());
        processDefinitionOutput.setDescription(processDefinition.getDescription());
        processDefinitionOutput.setVersion(processDefinition.getVersion());
        processDefinitionOutput.setDeploymentId(processDefinition.getDeploymentId());
        processDefinitionOutput.setResourceName(processDefinition.getResourceName());
        processDefinitionOutput.setDiagramResourceName(processDefinition.getDiagramResourceName());
        processDefinitionOutput.setStartFormKey(processDefinition.hasStartFormKey() ? 1 : 0);
        processDefinitionOutput.setGraphicalNotation(processDefinition.hasGraphicalNotation() ? 1 : 0);
        processDefinitionOutput.setSuspend(processDefinition.isSuspended() ? 2 : 1);
        processDefinitionOutput.setTenantId(processDefinition.getTenantId());
        processDefinitionOutput.setDerivedFrom(processDefinition.getDerivedFrom());
        processDefinitionOutput.setDerivedFromRoot(processDefinition.getDerivedFromRoot());
        processDefinitionOutput.setDerivedVersion(processDefinition.getDerivedVersion());
        processDefinitionOutput.setEngineVersion(processDefinition.getEngineVersion());
        return processDefinitionOutput;
    }

    private ProcessDefinitionQuery listProcessDefinitionByCondition(ProcessDefinitionCondition condition, ProcessDefinitionQuery processDefinitionQuery) {
        if (StringUtils.hasText(condition.getProcessDefinitionId())) {
            processDefinitionQuery.processDefinitionId(condition.getProcessDefinitionId());
        }
        if (StringUtils.hasText(condition.getDeploymentId())) {
            processDefinitionQuery.deploymentId(condition.getDeploymentId());
        }
        if (StringUtils.hasText(condition.getName())) {
            processDefinitionQuery.processDefinitionName(condition.getName());
        }
        if (StringUtils.hasText(condition.getCategory())) {
            processDefinitionQuery.processDefinitionCategory(condition.getCategory());
        }
        if (StringUtils.hasText(condition.getKey())) {
            processDefinitionQuery.processDefinitionKey(condition.getKey());
        }
        if (condition.getVersion() > 0) {
            // 查询指定版本的流程定义
            processDefinitionQuery.processDefinitionVersion(condition.getVersion());
        } else {
            // 默认查询最新版本的流程定义
            processDefinitionQuery.latestVersion();
        }
        if (condition.getSuspend() == 1) {
            processDefinitionQuery.active();
        }
        if (condition.getSuspend() == 2) {
            processDefinitionQuery.suspended();
        }
        if (StringUtils.hasText(condition.getTenantId())) {
            processDefinitionQuery.processDefinitionTenantId(condition.getTenantId());
        }
        return processDefinitionQuery;
    }

    @ApiOperation(value = "流程定义挂起,挂起后无法再创建新的流程实例")
    @PutMapping("/process-definitions/suspend/{processDefinitionId}")
    public Result<Boolean> suspendProcessDefinition(@PathVariable String processDefinitionId) {
        try {
            repositoryService.suspendProcessDefinitionById(processDefinitionId);
        } catch (FlowableObjectNotFoundException e1) {
            return ResultFactory.failed("流程id为：" + processDefinitionId + "的流程定义不存在", null);
        } catch (FlowableException e2) {
            return ResultFactory.failed("流程id为：" + processDefinitionId + "的流程已经是挂起状态", null);
        }
        return ResultFactory.success(Boolean.TRUE);
    }

    @ApiOperation(value = "流程定义挂起,挂起后无法再创建新的流程实例")
    @PutMapping("/process-definitions/suspend")
    public Result<Boolean> suspendProcessDefinition(@RequestBody SuspendProcessDefinitionInput input) {
        try {
            repositoryService.suspendProcessDefinitionById(input.getProcessDefinitionId(), input.isSuspendProcessInstances(), input.getSuspensionDate());
        } catch (FlowableObjectNotFoundException e1) {
            return ResultFactory.failed("流程id为：" + input.getProcessDefinitionId() + "的流程定义不存在", null);
        } catch (FlowableException e2) {
            return ResultFactory.failed("流程id为：" + input.getProcessDefinitionId() + "的流程已经是挂起状态", null);
        }
        return ResultFactory.success(Boolean.TRUE);
    }

    @ApiOperation(value = "流程定义挂起,会挂起所有key相同的流程定义")
    @PutMapping("/process-definitions/suspendByKey")
    public Result<Boolean> suspendProcessDefinitionByKey(@RequestBody SuspendProcessDefinitionKeyInput input) {
        try {
            repositoryService.suspendProcessDefinitionByKey(input.getProcessDefinitionKey(), input.isSuspendProcessInstances(), input.getSuspensionDate(), input.getTenantId());
        } catch (FlowableObjectNotFoundException e1) {
            return ResultFactory.failed("流程Key为：" + input.getProcessDefinitionKey() + "的流程定义不存在", null);
        } catch (FlowableException e2) {
            return ResultFactory.failed("流程Key为：" + input.getProcessDefinitionKey() + "的流程已经是挂起状态", null);
        }
        return ResultFactory.success(Boolean.TRUE);
    }


    @ApiOperation(value = "流程定义激活")
    @PutMapping("/process-definitions/activate/{processDefinitionId}")
    public Result<Boolean> activateProcessDefinitionById(@PathVariable String processDefinitionId) {
        try {
            repositoryService.activateProcessDefinitionById(processDefinitionId);
        } catch (FlowableObjectNotFoundException e1) {
            return ResultFactory.failed("流程id为：" + processDefinitionId + "的流程定义不存在或者已经是激活状态", null);
        }
        return ResultFactory.success(Boolean.TRUE);
    }

    @ApiOperation(value = "流程定义激活")
    @PutMapping("/process-definitions/activate")
    public Result<Boolean> activateProcessDefinition(@RequestBody ActivateProcessDefinitionInput input) {
        try {
            repositoryService.activateProcessDefinitionById(input.getProcessDefinitionId(), input.isActivateProcessInstances(), input.getActivateDate());
        } catch (FlowableObjectNotFoundException e1) {
            return ResultFactory.failed("流程id为：" + input.getProcessDefinitionId() + "的流程定义不存在", null);
        } catch (FlowableException e2) {
            return ResultFactory.failed("流程id为：" + input.getProcessDefinitionId() + "的流程已经是挂起状态", null);
        }
        return ResultFactory.success(Boolean.TRUE);
    }

    @ApiOperation(value = "查询流程定义的状态", httpMethod = "GET")
    @GetMapping("/process-definitions/is-suspended/{processDefinitionId}")
    public Result<Boolean> isProcessDefinitionSuspended(@PathVariable String processDefinitionId) {
        boolean suspended = repositoryService.isProcessDefinitionSuspended(processDefinitionId);
        return ResultFactory.success(suspended);
    }

    @ApiOperation(value = "查询身份信息", httpMethod = "GET")
    @GetMapping("/identity-links/{processDefinitionId}")
    public Result getIdentityLinks(@PathVariable String processDefinitionId) {
        List<IdentityLink> identityLinks = repositoryService.getIdentityLinksForProcessDefinition(processDefinitionId);
        return ResultFactory.success(identityLinks);
    }
    //==============================================流程定义相关api=================================================================

    //=============================================模型相关api=====================================================================
    @ApiOperation(value = "获取模型列表")
    @GetMapping("/models")
    public Result getModels(PageParam pageParam, ModelCondition condition) {
        ModelQuery modelQuery = repositoryService.createModelQuery();
        listModelByCondition(modelQuery, condition);
        PageResult<ProcessDefinitionOutput> pageResult = new PageResult(pageParam.getPageSize(), pageParam.getPageNum(),modelQuery.count(), modelQuery.list());
        return ResultFactory.success(pageResult);
    }

    private ModelQuery listModelByCondition(ModelQuery modelQuery, ModelCondition condition) {
        if (StringUtils.hasText(condition.getName())) {
            modelQuery.modelId(condition.getModelId());
        }
        if (StringUtils.hasText(condition.getName())) {
            modelQuery.modelName(condition.getName());
        }
        if (StringUtils.hasText(condition.getKey())) {
            modelQuery.modelKey(condition.getKey());
        }
        if (StringUtils.hasText(condition.getCategory())) {
            modelQuery.modelCategory(condition.getCategory());
        }
        if (condition.getVersion() > 0) {
            modelQuery.modelVersion(condition.getVersion());
        } else {
            modelQuery.latestVersion();
        }
        if (StringUtils.hasText(condition.getDeploymentId())) {
            modelQuery.deploymentId(condition.getDeploymentId());
        }
        if (StringUtils.hasText(condition.getTenantId())) {
            modelQuery.modelTenantId(condition.getTenantId());
        }
        return modelQuery;
    }

    @ApiOperation(value = "获取模型")
    @GetMapping("/models/{modelId}")
    public Result getModelById(@PathVariable String modelId) {
        Model model = repositoryService.getModel(modelId);
        return ResultFactory.success(model);
    }

    @ApiOperation(value = "创建模型")
    @PostMapping("/models")
    public Result createModels(@RequestBody ModelInput modelInput) {
        ModelEntityImpl model = new ModelEntityImpl();
        model.setCreateTime(new Date());
        buildModelEntity(modelInput, model);
        repositoryService.saveModel(model);
        return ResultFactory.success(null);
    }

    @ApiOperation(value = "更新模型")
    @PutMapping("/models/{modelId}")
    public Result updateModels(@PathVariable String modelId,@RequestBody ModelInput modelInput) {
        ModelEntityImpl model = new ModelEntityImpl();
        model.setId(modelId);
        model.setLastUpdateTime(new Date());
        buildModelEntity(modelInput, model);
        repositoryService.saveModel(model);
        return ResultFactory.success(null);
    }

    private ModelEntityImpl buildModelEntity(@RequestBody ModelInput modelInput, ModelEntityImpl model) {
        model.setName(modelInput.getName());
        model.setKey(modelInput.getKey());
        model.setCategory(modelInput.getCategory());
        model.setVersion(modelInput.getVersion());
        model.setMetaInfo(modelInput.getMetaInfo());
        model.setDeploymentId(modelInput.getDeploymentId());
        model.setTenantId(modelInput.getTenantId());
        return model;
    }


    @DeleteMapping("/models/{modelId}")
    public Result deleteModel(@PathVariable String modelId){
        repositoryService.deleteModel(modelId);
        return ResultFactory.success(null);
    }
    //=============================================模型相关api=====================================================================
}
