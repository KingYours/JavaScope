package com.lin.jin.you.springbootflowable.model.deployment;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/24    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("挂起流程定义Key输入对象")
public class SuspendProcessDefinitionKeyInput {

    @ApiModelProperty("流程定义Key")
    @NotBlank(message = "流程定义Key不能为空")
    private String processDefinitionKey;

    @ApiModelProperty("是否挂起流程实例，默认为false")
    private boolean suspendProcessInstances;

    @ApiModelProperty(value = "挂起日期;默认为Null,立刻挂起")
    private Date suspensionDate;

    @ApiModelProperty(value = "租户id")
    private String tenantId;
}
