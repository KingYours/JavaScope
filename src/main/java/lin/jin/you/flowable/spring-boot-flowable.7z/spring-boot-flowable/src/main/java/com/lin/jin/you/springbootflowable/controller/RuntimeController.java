package com.lin.jin.you.springbootflowable.controller;

import com.lin.jin.you.springbootflowable.model.instances.ProcessInstanceCondition;
import com.lin.jin.you.springbootflowable.model.instances.ProcessInstanceOutput;
import com.lin.jin.you.springbootflowable.model.instances.StartProcessInstanceInput;
import com.lin.jin.you.springbootflowable.page.PageParam;
import com.lin.jin.you.springbootflowable.page.PageResult;
import com.sunnada.gaia.commons.response.Result;
import com.sunnada.gaia.commons.response.ResultFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.flowable.common.engine.api.FlowableObjectNotFoundException;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.runtime.ProcessInstanceBuilder;
import org.flowable.engine.runtime.ProcessInstanceQuery;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 功能：bpmn流程实例相关api
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/4/26    Linjy     初版
 * ──────────────────────────────────────────
 */
@Api(tags = "流程实例操作API")
@RestController
@RequestMapping("/bpmn/runtime")
public class RuntimeController {

    @Resource
    private RuntimeService runtimeService;

    @ApiOperation(value = "启动流程实例")
    @PostMapping("/process-instances")
    public Result<ProcessInstanceOutput> startProcessInstance(@RequestBody StartProcessInstanceInput input) {
        if (StringUtils.hasText(input.getProcessDefinitionId()) || StringUtils.hasText(input.getProcessDefinitionKey())
                || StringUtils.hasText(input.getMessageName())) {
            ProcessInstanceBuilder processInstanceBuilder = runtimeService.createProcessInstanceBuilder();
            try {
                buildProcessInstanceBuilderParams(input, processInstanceBuilder);
                ProcessInstance processInstance = processInstanceBuilder.start();
                return ResultFactory.success(buildProcessInstanceOutput(processInstance));
            } catch (FlowableObjectNotFoundException e) {
                return ResultFactory.failed("流程定义不存在", null);
            }
        } else {
            String message = "通过processDefinitionId或者processDefinitionKey或者messageName启动一个实例，三者必填其一";
            return ResultFactory.failed(message, null);
        }
    }

    private ProcessInstanceOutput buildProcessInstanceOutput(ProcessInstance processInstance) {
        ProcessInstanceOutput output = new ProcessInstanceOutput();
        output.setProcessInstanceId(processInstance.getProcessInstanceId());
        output.setProcessDefinitionId(processInstance.getProcessDefinitionId());
        output.setProcessDefinitionName(processInstance.getProcessDefinitionName());
        output.setProcessDefinitionKey(processInstance.getProcessDefinitionKey());
        output.setProcessDefinitionVersion(processInstance.getProcessDefinitionVersion());
        output.setDeploymentId(processInstance.getDeploymentId());
        output.setBusinessKey(processInstance.getBusinessKey());
        output.setBusinessStatus(processInstance.getStartUserId());
        output.setSuspend(processInstance.isSuspended() ? 2 : 1);
        output.setProcessVariables(processInstance.getProcessVariables());
        output.setTenantId(processInstance.getTenantId());
        output.setName(processInstance.getName());
        output.setDescription(processInstance.getDescription());
        output.setStartTime(processInstance.getStartTime());
        output.setStartUserId(processInstance.getStartUserId());
        output.setCallbackId(processInstance.getCallbackId());
        output.setCallbackType(processInstance.getCallbackType());
        return output;
    }

    private ProcessInstanceBuilder buildProcessInstanceBuilderParams(StartProcessInstanceInput input, ProcessInstanceBuilder processInstanceBuilder) {
        if (StringUtils.hasText(input.getProcessDefinitionId())) {
            processInstanceBuilder.processDefinitionId(input.getProcessDefinitionId());
        }
        if (StringUtils.hasText(input.getProcessDefinitionKey())) {
            processInstanceBuilder.processDefinitionKey(input.getProcessDefinitionKey());
        }
        if (StringUtils.hasText(input.getMessageName())) {
            processInstanceBuilder.messageName(input.getMessageName());
        }
        if (StringUtils.hasText(input.getBusinessKey())) {
            processInstanceBuilder.businessKey(input.getBusinessKey());
        }
        if (!CollectionUtils.isEmpty(input.getVariables())) {
            processInstanceBuilder.variables(input.getVariables());
        }
        if (StringUtils.hasText(input.getTenantId())) {
            processInstanceBuilder.tenantId(input.getTenantId());
        }
        return processInstanceBuilder;
    }

    @ApiOperation(value = "删除正在运行的流程实例")
    @DeleteMapping("/process-instances/{processInstanceId}")
    public Result<Boolean> deleteProcessInstance(@PathVariable String processInstanceId, String deleteReason) {
        try {
            runtimeService.deleteProcessInstance(processInstanceId, deleteReason);
        } catch (FlowableObjectNotFoundException e) {
            return ResultFactory.failed("流程实例id：" + processInstanceId + "的流程实例不存在", null);
        }
        return ResultFactory.success(Boolean.TRUE);
    }

    @ApiOperation(value = "查询流程实例")
    @GetMapping("/process-instances")
    public Result getProcessInstances(PageParam pageParam, ProcessInstanceCondition condition) {
        ProcessInstanceQuery processInstanceQuery = runtimeService.createProcessInstanceQuery();
        listByCondition(condition, processInstanceQuery);
        List<ProcessInstance> processInstances = processInstanceQuery.listPage((pageParam.getPageNum() - 1) * pageParam.getPageSize(), pageParam.getPageNum() * pageParam.getPageSize());
        List<ProcessInstanceOutput> processInstanceOutputs = processInstances.stream().map(this::buildProcessInstanceOutput).collect(Collectors.toList());
        PageResult pageResult = new PageResult(pageParam.getPageSize(), pageParam.getPageNum(), processInstanceQuery.count(), processInstanceOutputs);
        return ResultFactory.success(pageResult);
    }

    private ProcessInstanceQuery listByCondition(ProcessInstanceCondition condition, ProcessInstanceQuery processInstanceQuery) {
        if (StringUtils.hasText(condition.getProcessInstanceId())) {
            processInstanceQuery.processInstanceId(condition.getProcessInstanceId());
        }
        if (StringUtils.hasText(condition.getProcessDefinitionId())) {
            processInstanceQuery.processDefinitionId(condition.getProcessDefinitionId());
        }
        if (StringUtils.hasText(condition.getProcessDefinitionName())) {
            processInstanceQuery.processDefinitionName(condition.getProcessDefinitionName());
        }
//        if (StringUtils.hasText(condition.getProcessDefinitionCategory())) {
//            processInstanceQuery.processDefinitionCategory(condition.getProcessDefinitionCategory());
//        }
        if (StringUtils.hasText(condition.getProcessInstanceBusinessKey())) {
            processInstanceQuery.processInstanceBusinessKey(condition.getProcessInstanceBusinessKey());
        }
        if (condition.getSuspend() == 1) {
            processInstanceQuery.active();
        }
        if (condition.getSuspend() == 2) {
            processInstanceQuery.suspended();
        }
        return processInstanceQuery;
    }
}
