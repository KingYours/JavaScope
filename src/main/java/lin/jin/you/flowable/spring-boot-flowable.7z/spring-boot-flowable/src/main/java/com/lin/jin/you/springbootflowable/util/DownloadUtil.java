package com.lin.jin.you.springbootflowable.util;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2021/11/9   kecz     初版
 * ──────────────────────────────────────────
 */
public class DownloadUtil {
    private static final String DEFAULT_CHARSET = StandardCharsets.UTF_8.displayName();

    public static final String DEFAULT_CONTENT_TYPE = "application/application_octet_stream";
    public static final String CONTENT_TYPE_XLS = "application/x-xls";

    /**
     * 下载文件
     *
     * @param fileName  文件名
     * @param fileBytes 文件字节流
     */
    public static void downloadFile(String fileName, byte[] fileBytes) throws Exception {
        downloadFile(fileName, fileBytes, DEFAULT_CONTENT_TYPE);
    }

    /**
     * @param fileName
     * @param fileBytes
     * @param contentType
     */
    public static void downloadFile(String fileName, byte[] fileBytes, String contentType) throws IOException {
        downloadFile(fileName, fileBytes, contentType, DEFAULT_CHARSET);
    }

    public static void downloadFile(String fileName, byte[] fileBytes, String contentType, String charSet) throws IOException {
        final HttpServletResponse response = HttpContextHolder.getResponse();
        initResponse(response, fileName, charSet, contentType);
        OutputStream os = response.getOutputStream();
        os.write(fileBytes);
        os.flush();
    }

    /**
     * 下载文件
     *
     * @param fileName    文件名
     * @param inputStream 文件流
     */
    public static void downloadFile(String fileName, InputStream inputStream) throws Exception {
        downloadFile(fileName, inputStream, DEFAULT_CONTENT_TYPE);
    }

    /**
     * @param fileName    文件名
     * @param inputStream 文件流
     * @param contentType content-type
     */
    public static void downloadFile(String fileName, InputStream inputStream, String contentType) throws IOException {
        downloadFile(fileName, inputStream, contentType, DEFAULT_CHARSET);
    }

    public static void downloadFile(String fileName, InputStream inputStream, String contentType, String charSet) throws IOException {
        final HttpServletResponse response = HttpContextHolder.getResponse();
        initResponse(response, fileName, charSet, contentType);
        fastCopyStream(inputStream, response.getOutputStream());
    }

    /**
     * 设置excel响应流
     *
     * @param fileName
     * @throws UnsupportedEncodingException
     */
    public static void initXlsResponse(String fileName) throws UnsupportedEncodingException {
        initResponse(HttpContextHolder.getResponse(), fileName, DEFAULT_CHARSET, CONTENT_TYPE_XLS);
    }

    /**
     * 设置响应流
     *
     * @param response    响应流
     * @param fileName    写出的文件名
     * @param charSet     字符集
     * @param contentType 内容类型
     * @throws UnsupportedEncodingException
     */
    public static void initResponse(HttpServletResponse response, String fileName, String charSet, String contentType) throws UnsupportedEncodingException {
        if (charSet == null) {
            charSet = DEFAULT_CHARSET;
        }
        if (contentType == null) {
            contentType = DEFAULT_CONTENT_TYPE;
        }
        response.setContentType(contentType);
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setCharacterEncoding(charSet);
        response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, charSet));
    }

    /**
     * 输入流与输出流快速拷贝
     *
     * @param inputStream  输入流
     * @param outputStream 输出流
     */
    public static void fastCopyStream(InputStream inputStream, OutputStream outputStream) throws IOException {
        try (final ReadableByteChannel readableByteChannel = Channels.newChannel(inputStream);
             final WritableByteChannel writableByteChannel = Channels.newChannel(outputStream)) {
            ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
            while (readableByteChannel.read(byteBuffer) != -1) {
                byteBuffer.flip();
                writableByteChannel.write(byteBuffer);
                byteBuffer.compact();
            }
            byteBuffer.flip();
            while (byteBuffer.hasRemaining()) {
                writableByteChannel.write(byteBuffer);
            }
            writableByteChannel.write(byteBuffer);
            outputStream.flush();
        } catch (IOException ioException) {
            throw ioException;
        }
    }
}
