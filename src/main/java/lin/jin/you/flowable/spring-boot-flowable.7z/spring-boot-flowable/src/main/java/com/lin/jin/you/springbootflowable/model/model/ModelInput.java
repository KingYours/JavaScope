package com.lin.jin.you.springbootflowable.model.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/5/7    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("模型输入对象")
public class ModelInput {

    @ApiModelProperty(value = "模型名称")
    private String name;

    @ApiModelProperty(value = "模型key")
    private String key;

    @ApiModelProperty(value = "模型分类")
    private String category;

    @ApiModelProperty(value = "模型版本")
    private int version = 1;

    @ApiModelProperty(value = "模型数据")
    private String metaInfo;

    @ApiModelProperty(value = "部署ID")
    private String deploymentId;

    @ApiModelProperty(value = "租户ID")
    private String tenantId = "";


}
