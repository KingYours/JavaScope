package com.lin.jin.you.springbootflowable.model.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0   2022/5/7    Linjy     初版
 * ──────────────────────────────────────────
 */
@Data
@ApiModel("模型条件对象")
public class ModelCondition {

    @ApiModelProperty(value = "模型ID")
    private String modelId;

    @ApiModelProperty(value = "模型名称")
    private String name;

    @ApiModelProperty(value = "模型key")
    private String key;

    @ApiModelProperty(value = "模型分类")
    private String category;

    @ApiModelProperty(value = "模型版本")
    private int version;

    @ApiModelProperty(value = "部署ID")
    private String deploymentId;

    @ApiModelProperty(value = "租户ID")
    private String tenantId = "";

}
