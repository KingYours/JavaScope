package com.lin.jin.you.springbootflowable.page;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能：
 * <p>
 * ──────────────────────────────────────────
 * version  变更日期    修改人    修改说明
 * ------------------------------------------
 * V1.0.0      kecz     初版
 * ──────────────────────────────────────────
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageResult<T> {

    private int pageSize;

    private int pageNum;

    private long total;

    private List<T> data;
}
